Please use DrRacket to open slides.rkt.
You can use any browser to open 4e.xhtml.
